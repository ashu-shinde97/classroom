package com.yash.classroom.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.classroom.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {

	User findByUsername(String username);

}
