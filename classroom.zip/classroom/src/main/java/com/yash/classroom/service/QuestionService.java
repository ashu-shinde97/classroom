package com.yash.classroom.service;

import java.util.Set;

import com.yash.classroom.model.Questions;
import com.yash.classroom.model.Quiz;

public interface QuestionService {
	public Questions addQuestion(Questions questions);

	public Questions updateQuestions(Questions questions);

	public Set<Questions> getQuestions();

	public Questions getQuestion(Integer questionId);

	public Set<Questions> getQuestionsOfQuiz(Quiz quiz);

	public void deleteQuestion(Integer questionId);

}
