package com.yash.classroom.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.classroom.model.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {

}
