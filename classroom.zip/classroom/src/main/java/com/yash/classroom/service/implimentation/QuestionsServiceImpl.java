package com.yash.classroom.service.implimentation;

import java.util.HashSet;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.classroom.model.Questions;
import com.yash.classroom.model.Quiz;
import com.yash.classroom.repo.QuestionRepository;
import com.yash.classroom.service.QuestionService;

@Service
public class QuestionsServiceImpl implements QuestionService {
	
	@Autowired
	private QuestionRepository questionRepository;
	
	@Override
	public Questions addQuestion(Questions questions) {
		// TODO Auto-generated method stub
		return this.questionRepository.save(questions);
	}

	@Override
	public Questions updateQuestions(Questions questions) {
		// TODO Auto-generated method stub
		return this.questionRepository.save(questions);
	}

	@Override
	public Set<Questions> getQuestions() {
		// TODO Auto-generated method stub
		return new HashSet<>(this.questionRepository.findAll());
	}

	@Override
	public Questions getQuestion(Integer questionId) {
		// TODO Auto-generated method stub
		return this.questionRepository.findById(questionId).get();
	}

	@Override
	public Set<Questions> getQuestionsOfQuiz(Quiz quiz) {
		// TODO Auto-generated method stub
		return this.questionRepository.findByQuiz(quiz);
	}

	@Override
	public void deleteQuestion(Integer questionId) {
		// TODO Auto-generated method stub
		Questions question = new Questions();
		question.setQueId(questionId);
		this.questionRepository.delete(question);
		
	}


}
