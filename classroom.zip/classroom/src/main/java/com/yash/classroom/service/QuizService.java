package com.yash.classroom.service;

import java.util.Set;

import com.yash.classroom.model.Quiz;

public interface QuizService {
	public Quiz addQuiz(Quiz quiz);

	public Quiz updateQuiz(Quiz quiz);

	public Set<Quiz> getQuizzes();

	public Quiz getQuiz(Integer quizId);

	public void deleteQuiz(Integer quizId);

}
