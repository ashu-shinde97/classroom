package com.yash.classroom.service;

import java.util.Set;

import com.yash.classroom.model.User;
import com.yash.classroom.model.UserRole;

public interface UserService {
	
	//create user
	public User createUser(User user,Set<UserRole> userRoles) throws Exception;
	
	//getuser
	public User getuser(String username);
	
	//delete user by id
	public void deleteUser(Integer id);
	
	//update by id
//	public User UpdateUser(User user,Set<UserRole> userRoles,Integer id);
}
