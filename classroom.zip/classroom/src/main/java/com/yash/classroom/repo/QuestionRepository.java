package com.yash.classroom.repo;


import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.classroom.model.Questions;
import com.yash.classroom.model.Quiz;

public interface QuestionRepository extends JpaRepository<Questions, Integer> {

	Set<Questions> findByQuiz(Quiz quiz);

	

}
