package com.yash.classroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassroomApplicationTests {

	@Test
	void contextLoads() {
	}

}
